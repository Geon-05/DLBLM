document.addEventListener('DOMContentLoaded', function() {
    console.log("JavaScript 파일이 성공적으로 로드되었습니다!");
});

const app = Vue.createApp({
    data() {
        return {
            text: '',        // 출력될 텍스트
            inputText: ''    // 입력된 텍스트를 임시 저장
        };
    },
    methods: {
        // 버튼 클릭 이벤트 처리 메서드
        click() {
            this.text = this.inputText; // inputText 값을 text로 업데이트
            console.log("전송 버튼 클릭 - inputText:", this.inputText, "text:", this.text);
            this.inputText = ''; // 입력 필드 초기화
        }
    }
}).mount("#app");