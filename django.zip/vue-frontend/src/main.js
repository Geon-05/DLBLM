import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'
import axios from 'axios';


createApp(App).mount('#app')

// Axios 전역 설정 (필요 시 설정)
app.config.globalProperties.$axios = axios;
app.mount('#app');