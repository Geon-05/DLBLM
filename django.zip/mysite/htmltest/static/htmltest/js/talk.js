document.addEventListener('DOMContentLoaded', function() {
    console.log("JavaScript 파일이 성공적으로 로드되었습니다!");

    // 😎수정부분
    result = request.sendrequest
    ({
        url: "/myapp/hello/",
        body: param
    })
    
    // 추가적인 JavaScript 코드 작성
});